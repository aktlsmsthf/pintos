#include <stdio.h>


void
test_hello (void) 
{
  printf("hello, world!");
}
